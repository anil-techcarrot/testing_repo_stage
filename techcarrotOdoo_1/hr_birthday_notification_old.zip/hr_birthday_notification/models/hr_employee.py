import base64
import datetime
import io
import logging
import os
import urllib.request

from odoo import models
from PIL import Image, ImageDraw, ImageFont, ImageOps

_logger = logging.getLogger(__name__)

HR_REVIEWER_GROUP_NAME = 'HR Reviewer'

BACKGROUND_URL = "https://lh3.googleusercontent.com/d/1R_DcmIU6OefuaSdNNS0GOQC60DxSXMwA"


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    def _cron_send_birthday_notifications(self):
        today = datetime.date.today()
        employees = self.sudo().search([('birthday', '!=', False)])
        birthday_employees = employees.filtered(
            lambda e: e.birthday.day == today.day and e.birthday.month == today.month
        )
        for emp in birthday_employees:
            emp._send_birthday_card_email()

    def _get_hr_reviewer_emails(self):
        group = self.env['res.groups'].sudo().search(
            [('name', '=', HR_REVIEWER_GROUP_NAME)], limit=1
        )
        if not group:
            _logger.warning(
                "Group '%s' not found; no birthday emails will be sent.",
                HR_REVIEWER_GROUP_NAME,
            )
            return []
        emails = [u.email for u in group.user_ids if u.email]
        if not emails:
            _logger.warning(
                "Group '%s' has no users with an email set.", HR_REVIEWER_GROUP_NAME
            )
        return emails

    def _build_birthday_card(self):
        self.ensure_one()

        with urllib.request.urlopen(BACKGROUND_URL) as resp:
            background = Image.open(io.BytesIO(resp.read())).convert('RGBA')
        background = background.resize((2500, 2500))

        if self.image_1920:
            photo = Image.open(io.BytesIO(base64.b64decode(self.image_1920))).convert('RGBA')
            photo = ImageOps.fit(photo, (560, 650), method=Image.LANCZOS)

            mask = Image.new('L', (560, 650), 0)
            ImageDraw.Draw(mask).rounded_rectangle([0, 0, 560, 650], radius=25, fill=255)
            background.paste(photo, (395, 770), mask)

        draw = ImageDraw.Draw(background)
        font_candidates = [
            r'C:\Windows\Fonts\arialbd.ttf',
            r'C:\Windows\Fonts\calibrib.ttf',
            r'C:\Windows\Fonts\seguisb.ttf',
            '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
        ]
        font_path = next((p for p in font_candidates if os.path.exists(p)), None)

        max_text_width = 1300
        font_size = 220
        font = None
        while font_size > 40:
            if font_path:
                font = ImageFont.truetype(font_path, font_size)
            else:
                font = ImageFont.load_default()
                _logger.warning("No TrueType font found on this system; name will render small.")
                break
            bbox = draw.textbbox((0, 0), self.name, font=font)
            text_width = bbox[2] - bbox[0]
            if text_width <= max_text_width:
                break
            font_size -= 10

        text_pos = (1140, 1340)
        draw.text((text_pos[0] + 3, text_pos[1] + 3), self.name, font=font, fill=(0, 0, 0, 160))
        draw.text(text_pos, self.name, font=font, fill=(255, 255, 255, 255))

        output = io.BytesIO()
        background.convert('RGB').save(output, format='PNG')
        return output.getvalue()

    def _send_birthday_card_email(self):
        self.ensure_one()

        hr_emails = self._get_hr_reviewer_emails()
        if not hr_emails:
            return

        try:
            card_bytes = self._build_birthday_card()
        except Exception:
            _logger.exception("Failed to build birthday card for %s", self.name)
            return

        attachment = self.env['ir.attachment'].sudo().create({
            'name': f'birthday_{self.id}.png',
            'datas': base64.b64encode(card_bytes),
            'public': True,
        })
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        image_url = f"{base_url}/web/image/{attachment.id}"

        mail = self.env['mail.mail'].sudo().create({
            'subject': f'Happy Birthday - {self.name}',
            'email_to': ','.join(hr_emails),
            'body_html': f'<img src="{image_url}" style="max-width:600px;"/>',
        })
        mail.send()